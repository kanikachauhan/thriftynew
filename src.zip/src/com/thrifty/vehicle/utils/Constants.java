package com.thrifty.vehicle.utils;

public class Constants {

	public static String SQLITE_CONNECTION_STRING = "jdbc:sqlite:thriftyRent.db";
	public static String SQLITE_CLASS_LOADER = "org.sqlite.JDBC";
	public static String SQLITE_DB_NAME = "thriftyRent.db";
}
