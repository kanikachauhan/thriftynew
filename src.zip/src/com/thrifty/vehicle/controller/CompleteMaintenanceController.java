package com.thrifty.vehicle.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class CompleteMaintenanceController implements Initializable{

	@FXML
	private Button close;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		close.setOnAction(event->{
			Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
			stage.close();
		});
	} 

}
