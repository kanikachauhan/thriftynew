package com.thrifty.vehicle.config;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import com.thrifty.vehicle.model.Vehicle;
import com.thrifty.vehicle.utils.Constants;

public class DatabaseConfig {
	private static Connection connection = null;
	static {
		try {
			File file = new File(Constants.SQLITE_DB_NAME);
			if(!file.exists()) {
				Class.forName(Constants.SQLITE_CLASS_LOADER);
				connection = DriverManager.getConnection(Constants.SQLITE_CONNECTION_STRING);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public List<Vehicle> listAllVehicles(){
		List<Vehicle> vehicleList = new ArrayList<Vehicle>();
		try{
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return vehicleList;
	}
	public String maintainVehicle(String vehicleId) {
		return "true";
	}
	public String completeMaintenanceOfVehicle(String vehicleId) {
		return "true";
	}
}
