package com.thrifty.vehicle.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MenuController implements Initializable{

	@FXML
	private MenuItem  addMenu,exportMenu,importMenu,closeMenu,rentMenu,returnMenu,maintainMenu,completeMenu;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		addMenu.setOnAction(event->{
			AnchorPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/AddVehicle.fxml"));
				createScene(root,600,550);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		exportMenu.setOnAction(event->{
			
		});
		importMenu.setOnAction(event->{
			
		});
		maintainMenu.setOnAction(event->{
			AnchorPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/MaintainVehicle.fxml"));
				createScene(root,600,250);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		completeMenu.setOnAction(event->{
			AnchorPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/MaintainVehicleComplete.fxml"));
				createScene(root,600,250);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		closeMenu.setOnAction(event->{
			System.exit(1);
		});
		returnMenu.setOnAction(event->{
			AnchorPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/ReturnVehicle.fxml"));
				createScene(root,600,250);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		rentMenu.setOnAction(event->{
			AnchorPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/RentVehicle.fxml"));
				createScene(root,600,350);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	private void createScene(AnchorPane root,int width,int height) {
		try {
			Stage stage = new Stage();
			stage.initStyle(StageStyle.UNDECORATED);
			stage.initModality(Modality.APPLICATION_MODAL);
			Scene scene = new Scene(root,width,height);
			stage.setResizable(false);
			stage.setScene(scene);
			stage.show();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
}
