package com.thrifty.vehicle.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class MainController implements Initializable{

	@FXML
	private AnchorPane mainPane;
	@FXML
	private BorderPane mainBorderPane;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("com/thrifty/vehicle/view/Menu.fxml"));
			AnchorPane root = loader.load();
			mainBorderPane.setTop(root);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

}
