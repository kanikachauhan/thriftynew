package com.thrifty.vehicle.model;

public class Car extends Vehicle{

}
