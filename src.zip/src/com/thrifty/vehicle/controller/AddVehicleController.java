package com.thrifty.vehicle.controller;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AddVehicleController implements Initializable{

	@FXML
	private Button close,browse;
	@FXML
	private GridPane gridPane;
	FileChooser fileChooser = new FileChooser();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		HBox hbox = new HBox();
		close.setOnAction(event->{
			Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
			stage.close();
		});
		browse.setOnAction(event->{
			Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
			File file = fileChooser.showOpenDialog(stage);
			
		});
	} 
}